import React from "react";
import { StyleSheet, Text, View, Image } from "react-native";
import { useNavigation } from "@react-navigation/core";
const SplashArt = () => {
  const navigation = useNavigation();
  setTimeout(() => {
    navigation.replace("Login");
  }, 5000);

  return (
    <View
      style={{
        height: "100%",
        backgroundColor: "#42A37C",
      }}
    >
      <View
        style={{
          backgroundColor: "#42A37C",
          height: "100%",

          marginTop: 250,
          alignItems: "center",
        }}
      >
        <Image
          source={require("../assets/logo.png")}
          style={{
            width: 70,
            height: 70,
            marginBottom: 10,
          }}
        />
        <Text
          style={{
            fontSize: 36,
            color: "white",
            fontWeight: "700",
          }}
        >
          SmartFlowerPot
        </Text>
      </View>
    </View>
  );
};

export default SplashArt;
