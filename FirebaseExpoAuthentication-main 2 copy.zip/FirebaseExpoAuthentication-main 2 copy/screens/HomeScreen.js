import { useNavigation } from "@react-navigation/core";

import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { auth } from "../firebase";
import React, { useEffect, useState } from "react";
const HomeScreen = () => {
  const navigation = useNavigation();

  const mail = auth.currentUser?.email;
  let meno = "";
  for (let i = 0; i < mail.length; i++) {
    if (mail[i] === "@") {
      break;
    } else {
      meno += mail[i];
    }
  }

  const handleSignOut = () => {
    auth
      .signOut()
      .then(() => {
        navigation.replace("Login");
      })
      .catch((error) => alert(error.message));
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={handleSignOut} style={styles.button}>
        <Text style={styles.buttonText}>Sign out</Text>
      </TouchableOpacity>
      <Text>Vitaj {meno}</Text>
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  container: {
    marginTop: 60,
    padding: 20,
  },
  button: {
    backgroundColor: "#42A37C",
    width: "60%",
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 40,
  },
  buttonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
  },
});
