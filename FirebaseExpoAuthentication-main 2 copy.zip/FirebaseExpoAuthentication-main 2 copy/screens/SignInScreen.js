import { useNavigation } from "@react-navigation/core";
import React, { useEffect, useState } from "react";
import {
  KeyboardAvoidingView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Image,
} from "react-native";
import { auth } from "../firebase";

const SignInScreen = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const navigation = useNavigation();

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        console.log(auth);
        navigation.replace("Home");
      }
    });

    return unsubscribe;
  }, []);
  const SignIn = () => {
    navigation.replace("Login");
  };
  const handleSignUp = () => {
    auth
      .createUserWithEmailAndPassword(email, password)
      .then((userCredentials) => {
        const user = userCredentials.user;
        console.log("Registered with:", user.email);
      })
      .catch((error) => alert(error.message));
  };

  const handleLogin = () => {
    auth
      .signInWithEmailAndPassword(email, password)
      .then((userCredentials) => {
        const user = userCredentials.user;
        console.log("Logged in with:", user.email);
      })
      .catch((error) => alert(error.message));
  };
  return (
    <KeyboardAvoidingView style={styles.container} behavior="padding">
      <View style={{ alignItems: "center", marginTop: 80, marginBottom: 50 }}>
        <Image
          source={require("../assets/logo.png")}
          style={{
            width: 70,
            height: 70,
            marginBottom: 10,
          }}
        />
        <Text
          style={{
            fontSize: 36,
            fontWeight: "700",
            color: "white",
          }}
        >
          SmartFlowerPot
        </Text>
      </View>
      <View
        style={{
          width: "100%",
          alignItems: "center",
          flex: 1,
          backgroundColor: "#F8F8F8",
          borderRadius: 50,
          padding: 40,
        }}
      >
        <Text
          style={{
            fontSize: 18,
            fontWeight: "400",
            color: "#717074",
          }}
        >
          <Text
            style={{
              color: "#42A37C",
            }}
          >
            Register
          </Text>{" "}
          with your account.
        </Text>
        <View style={styles.inputContainer}>
          <Text
            style={{
              color: "#4A4A4A",
              padding: 0,
              fontSize: 12,
            }}
          >
            Email Address
          </Text>
          <TextInput
            placeholder="Email Address"
            value={email}
            onChangeText={(text) => setEmail(text)}
            style={styles.input}
          />

          <Text
            style={{
              color: "#4A4A4A",
              padding: 0,
              paddingTop: 10,
              fontSize: 12,
            }}
          >
            Password
          </Text>
          <TextInput
            placeholder="Password"
            value={password}
            onChangeText={(text) => setPassword(text)}
            style={styles.input}
            secureTextEntry
          />
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity onPress={handleSignUp} style={styles.button}>
            <Text style={styles.buttonText}>Register</Text>
          </TouchableOpacity>
        </View>
        <Text style={{ marginTop: 30, fontWeight: "500", color: "#4A4A4A" }}>
          Do you have an account already?
          <TouchableOpacity onPress={SignIn}>
            <Text style={{ color: "#42A37C", fontWeight: "600" }}> Log in</Text>
          </TouchableOpacity>
        </Text>
      </View>
    </KeyboardAvoidingView>
  );
};

export default SignInScreen;
const styles = StyleSheet.create({
  container1: {
    alignItems: "center",
  },
  flower: {
    fontSize: 36,
    fontWeight: "700",
    color: "green",
  },
  container: {
    flex: 1,

    alignItems: "center",
    backgroundColor: "#42A37C",
  },
  inputContainer: {
    width: "100%",
    marginTop: 30,
  },
  input: {
    backgroundColor: "white",
    paddingHorizontal: 15,
    paddingVertical: 13,
    borderRadius: 10,
    marginTop: 5,
  },
  buttonContainer: {
    width: "100%",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 40,
  },
  button: {
    backgroundColor: "#42A37C",
    width: "100%",
    padding: 20,
    borderRadius: 20,
    alignItems: "center",
  },
  buttonOutline: {
    backgroundColor: "white",
    marginTop: 5,
    borderColor: "green",
    borderWidth: 2,
  },
  buttonText: {
    color: "white",
    fontWeight: "700",
    fontSize: 16,
  },
  buttonOutlineText: {
    color: "green",
    fontWeight: "700",
    fontSize: 16,
  },
});
